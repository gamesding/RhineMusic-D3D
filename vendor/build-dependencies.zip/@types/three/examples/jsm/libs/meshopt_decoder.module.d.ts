export * from "meshoptimizer/decoder";
